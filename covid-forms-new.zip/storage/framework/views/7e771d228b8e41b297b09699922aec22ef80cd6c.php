<?php $__env->startSection('content'); ?>
<?php
$site_title =__('messages.title');
$site_subtitle =__('messages.subtitle');
$participate =__('messages.participate');

 if (LaravelLocalization::getCurrentLocale()=='fr' ):
    $suivant ="Suivant";
    $precedent ="Precédent";
    $terminer ="Terminer";

 elseif (LaravelLocalization::getCurrentLocale()=='ar') :

     $suivant ="التالي";
     $precedent ="السابق";
     $terminer ="إرسال";
    endif;

?>
<template>

    <v-system-bar
    dark
    color=<?php echo e($color); ?>

  >


  <span> Numéro vert  : </span>
  <v-icon> mdi-phone</v-icon>


  <span> 3030 </span>

    <v-spacer></v-spacer>
     <!--
    <v-icon>mdi-email</v-icon>
    <span>convid19@sante.gov.dz </span>
    -->
    <v-spacer></v-spacer>
       <!--
    <v-icon>mdi-facebook</v-icon>
    <v-icon>mdi-twitter</v-icon>
    <v-icon>mdi-google-plus</v-icon>
    -->

   <span>
    <v-breadcrumbs>
      <v-breadcrumbs-item class="white-link"
      href="<?php echo e(LaravelLocalization::getLocalizedURL("fr", null, [], true)); ?>"

      >
        Français
      </v-breadcrumbs-item>
      <v-breadcrumbs-item class="white-link"
        href="<?php echo e(LaravelLocalization::getLocalizedURL("ar", null, [], true)); ?>"

      >
      عربي
      </v-breadcrumbs-item>
  </v-breadcrumbs>

   </span>






  </v-system-bar>

<div class="flex-center position-ref full-height">
          <user-survey-vuetify survey_id=<?php echo e($survey_id); ?> lang=<?php echo e(LaravelLocalization::getCurrentLocale()); ?> flt="right" shape=<?php echo e($shape); ?>  color=<?php echo e($color); ?> surveytitle=<?php echo e($surveytitle); ?> surveysubtitle=<?php echo e($surveysubtitle); ?>

site_title="<?php echo e($site_title); ?>"
         site_subtitle="<?php echo e($site_subtitle); ?>" participate="<?php echo e($participate); ?>"
         suivant ="<?php echo e($suivant); ?>"  precedent ="<?php echo e($precedent); ?>"   terminer ="<?php echo e($terminer); ?>"
         >
        </user-survey-vuetify>



</div>

</template>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.guest-survey', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\covid-forms-new\resources\views\user-survey.blade.php ENDPATH**/ ?>