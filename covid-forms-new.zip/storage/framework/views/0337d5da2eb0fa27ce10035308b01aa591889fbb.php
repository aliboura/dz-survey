<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <link href="<?php echo e(asset('public/css/app.css')); ?>" rel="stylesheet">
</head>
<body>
  <div id="app">
    <v-app>

    <main class="py-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
  </v-app>
  </div>

    <script src="<?php echo e(asset('public/js/app.js')); ?>"></script>
   
</body>
</html>
<?php /**PATH C:\laragon\www\covid-forms-new\resources\views\layouts\guest.blade.php ENDPATH**/ ?>