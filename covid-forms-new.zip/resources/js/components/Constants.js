
const BASE_URL ="https://djz-forms.000webhostapp.com/"
const BASE_API_URL ="https://djz-forms.000webhostapp.com/api/"


export default {

  BASE_URL :BASE_URL,
  BASE_API_URL :BASE_API_URL
}

